# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '911d20c29d25651d78caa50699b0400ce5410b86f35508ac8b2411d7ae2c39b825339d815b5e4370caa18c91fbb5a10c63cd603a1b7411668d6ebf2be71ab424'